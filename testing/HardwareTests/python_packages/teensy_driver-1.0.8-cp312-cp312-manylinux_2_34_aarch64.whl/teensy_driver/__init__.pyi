from typing import List, Union


class Header:
    sync1: int
    sync2: int
    msg_type: int
    size: int

class Footer:
    crc: int
    sync: int

class GimbalAnglesStruct:
    SkrLogicState: int
    SkrSubLogicState: int
    PBITStatus: int
    PBITResults: int
    IBITStatus: int
    IBITResults: int
    CALIBStatus: int
    CALIBResults: int
    CBITResults: int
    SkrCntYawMode: int
    SkrCntPitchMode: int
    GimbalYawAngleCor: float
    GimbalPitchAngleCor: float
    YawRateCor: float
    PitchRateCor: float
    RollRateCor: float
    ControlFrameCounter: int
    YawMotorCmd: float
    PitchMotorCmd: float
    YawPWMCmd: float
    PitchPWMCmd: float


class CalibData:
    def __init__(self, A_Matrix: list[float], A_ScaleFactor: list[float]):
        """
        :param A_Matrix: Float list of len 9.
        :param A_ScaleFactor: Float list of len 3: `[A_xAcceleration, A_yAcceleration, A_zAcceleration]`.
        """

class GimbalAnglesMessage:
    header: Header
    GimbalAngleData_1: GimbalAnglesStruct
    footer: Footer

class GimbalCommandMessage:
    header: Header
    systemTimeTag: float
    LogicStateCmd: int
    SubLogicStateCmd: int
    BitRequestCmd: int
    RollGyroBias: float
    PitchGyroBias: float
    YawGyroBias: float
    SkrCntYawModeCmd: int
    SkrCntPitchModeCmd: int
    GimbalYawCmd: float
    GimbalPitchCmd: float
    IMU_P_Raw: float
    IMU_Q_Raw: float
    IMU_R_Raw: float
    footer: Footer

    def __init__(self, systemTimeTag: int, LogicStateCmd: int, SubLogicStateCmd: int, BitRequestCmd: int,
                        RollGyroBias: float, PitchGyroBias: float, YawGyroBias: float, SkrCntYawModeCmd: int, 
                        SkrCntPitchModeCmd: int, GimbalYawCmd: float, GimbalPitchCmd: float, IMU_P_Raw: float, IMU_Q_Raw: float, IMU_R_Raw: float): ...


class LogLevel:
    Debug: "LogLevel"
    Info: "LogLevel"
    Warning: "LogLevel"
    Error: "LogLevel"
    Critical: "LogLevel"

class Log:
    message: str
    level: LogLevel

class UartDriver:
    device: str
    baud_rate: int
    max_buffer_size: int

    def __init__(self, device: str, baud_rate: int, max_buffer_size: int, serial_timeout: int, log_buffer_size: int, log_dir: str, use_udp: bool, bind_addr: str, remote_addr: str):
        """
        :param device: Serial port name.
        :param baud_rate: Serial baud rate.
        :param max_buffer_size: Max serial read buffer size.
        :param serial_timeout: Serial read timeout in milliseconds.
        """
    def init_driver(self, calib_data: CalibData): ...
    def start(self): ...
    def driver_logic(self): ...
    def get_gimbal_angles(self) -> Union[GimbalAnglesMessage, None]:
        """
        Pops a gimbal angles message from the message queue.
        :return: If the queue is not empty, return its front, otherwise return None.
        """
    def write_gimbal_cmd(self, cmd: GimbalCommandMessage): ...
    def is_connected(self) -> bool: ...
    def get_log(self) -> Union[Log, None]:
        """
        Pops a log from the log queue.
        :return: If the queue is not empty, return its front, otherwise return None.
        """
    def get_gcs_version(self) -> Union[str, None]: ...
    def get_gcs_manager_version(self) -> Union[str, None]: ...
    def get_driver_version(self) -> str: ...

def parse_bin(path: str) -> None: ...

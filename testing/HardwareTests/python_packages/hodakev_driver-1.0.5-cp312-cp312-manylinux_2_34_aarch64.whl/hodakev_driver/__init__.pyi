from typing import Union

class HodAkevLogicStatus:
    Idle: 'HodAkevLogicStatus'
    Init: 'HodAkevLogicStatus'
    CalibrationMatrix: 'HodAkevLogicStatus'
    Operational: 'HodAkevLogicStatus'
    Error: 'HodAkevLogicStatus'

class CalibrationMatrix:
    data: bytes

class HodAkevMessage:
    ts: float
    imu_sets: list[imu_set_struct]
    mag_sets: mag_set_struct
    baro_time: float
    baro: float
    temp: float
    imu_ts: float
    baro_counter: int

class imu_set_struct:
    acc: list[float]
    gyro: list[float]

class mag_set_struct:
    flux: list[float]
    mmc_set_reset: int
    sensor_ts: float

class UartDriver:
    def __init__(self, device: str, baud_rate: int, max_buffer_size: int, log_buffer_size: int, use_udp: bool, bind_addr: str, remote_addr: str): ...
    def init_driver(self, log_dir: str): ...
    def start(self): ...
    def driver_logic(self): ...
    def get_imu_msg(self) -> Union[HodAkevMessage, None]: ...
    def get_calibration_data(self) -> Union[CalibrationMatrix, None]: ...
    def get_versions(self) -> dict[str, list[int]]: ...
    def get_logic_status(self) -> HodAkevLogicStatus: ...

def read_bin(): ...
